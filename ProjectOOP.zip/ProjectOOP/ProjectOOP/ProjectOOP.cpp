#include "GameApp.h"

int main() {
    GameApp app;
    app.menu();
    return 0;
}
